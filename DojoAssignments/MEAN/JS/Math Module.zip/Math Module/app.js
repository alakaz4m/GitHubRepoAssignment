var mathlib = require('./mathlib');
mathlib().add(10,10);
