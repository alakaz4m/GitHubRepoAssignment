from django.shortcuts import render, redirect
from .models import League, Team, Player
from django.db.models import Q

from . import team_maker

def index(request):
	context = {
		# "leagues": League.objects.all(),
		# "teams": Team.objects.all(),
		# "players": Player.objects.all(),
		"baseball_leagues": League.objects.filter(sport__icontains='baseball'),
		"womens_league": League.objects.filter(name__icontains='women'),
		"hockey_league": League.objects.filter(sport__icontains='hockey'),
		"nofootballleagues": League.objects.exclude(sport__icontains='football'),
		"conferenceleagues": League.objects.filter(name__icontains='conference'),
		"atlantic": League.objects.filter(name__icontains='atlantic'),
		"dallas": Team.objects.filter(location__icontains='dallas'),
		"raptors": Team.objects.filter(team_name__icontains='raptors'),
		"cityteams": Team.objects.filter(location__icontains='city'),
		"t_teams": Team.objects.filter(team_name__startswith="T"),
		"abc_teams": Team.objects.all().order_by('location'),
		"reverse_teams": Team.objects.all().order_by('-location'),
		"cooper_names": Player.objects.filter(last_name__icontains='cooper'),
		"joshua_names": Player.objects.filter(first_name__icontains='joshua'),
		"no_joshua_cooper": Player.objects.filter(last_name__icontains='cooper').exclude(first_name__icontains='joshua'),
		"alexander_wyatt": Player.objects.filter(Q(first_name__icontains='alexander') | Q(first_name__icontains='wyatt')).order_by('last_name'),
	}
	return render(request, "leagues/index.html", context)

def two(request):
	context = {
		"atlanticteams": Team.objects.filter(league__name__icontains='atlantic'),
		"bostonpenguins": Player.objects.filter(curr_team__team_name__icontains='penguins'),
		"college_bball": Player.objects.filter(curr_team__league__name = 'International Collegiate Baseball Conference'),
		"football_league": Player.objects.filter(Q(last_name = 'Lopez') & Q(curr_team__league__name = 'American Conference of Amateur Football')),
		"allfootballplayers": Player.objects.filter(curr_team__league__sport__icontains='football'),
		"sophiaplayers": Player.objects.filter(first_name ='Sophia'),
		"noflores": Player.objects.filter(last_name__icontains = 'flores').exclude(curr_team__team_name__icontains='Roughriders')
	}
	return render(request, "leagues/index_level2.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")
